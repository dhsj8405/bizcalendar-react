import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import './App.css';
import React, { useState, useEffect } from 'react';

import HomePage from "./pages/HomePage";
import Login from './pages/Login';
import Layout from "./components/layout/Layout";
import SettingsPage from "./pages/SettingsPage";
function App() {
  const [isLoggedIn, setLoggedIn] = useState(false); // 로그인 상태

  return (
    
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="/setting" element={<SettingsPage />} />
      </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
