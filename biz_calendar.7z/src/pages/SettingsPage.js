import React from 'react';

const SettingsPage = () => {
    return (
        <div>
            환경설정 페이지
        </div>
    );
};

export default SettingsPage;