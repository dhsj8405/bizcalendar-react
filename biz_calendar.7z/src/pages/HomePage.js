import React from 'react'
import Calendar from '../components/calendar/Calendar.js'

export default function Home() {
  return (
    <>
      <Calendar/>
    </>
    
  )
}